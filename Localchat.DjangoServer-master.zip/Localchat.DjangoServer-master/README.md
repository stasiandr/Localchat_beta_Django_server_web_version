Localchat.DjangoServer
======================
First Show of our poject
Next we will create en open tutorial and then post it here
